from django.apps import AppConfig


class ArtcileConfig(AppConfig):
    name = 'artcile'
